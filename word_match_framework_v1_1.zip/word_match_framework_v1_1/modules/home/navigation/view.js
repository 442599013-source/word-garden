// 首页 / navigation/view.js
// 框架占位：尚未移植原游戏逻辑。
export const scaffoldOnly = true;

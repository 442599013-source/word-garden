# 测试 / smoke/README.md

框架占位，尚未填充正式功能。

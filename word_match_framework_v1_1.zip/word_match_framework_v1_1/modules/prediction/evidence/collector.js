// PTE自动预测 / evidence/collector.js
// 框架占位：尚未移植原游戏逻辑。
export const scaffoldOnly = true;

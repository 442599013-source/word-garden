// 单词消消乐 / index.js
// 框架占位：尚未移植原游戏逻辑。
export const scaffoldOnly = true;

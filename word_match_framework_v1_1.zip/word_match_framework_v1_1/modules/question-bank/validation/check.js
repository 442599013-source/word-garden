// 课程题库 / validation/check.js
// 框架占位：尚未移植原游戏逻辑。
export const scaffoldOnly = true;

# 图片与音频 / stages/junior/README.md

框架占位，尚未填充正式功能。

// 统一模块加载入口；默认所有模块未启用，避免占位代码被当作真实功能。
export async function loadModule(name, registry) {
  const item = registry?.modules?.[name];
  if (!item || !item.enabled) throw new Error(`模块尚未启用：${name}`);
  return import(item.entry);
}
